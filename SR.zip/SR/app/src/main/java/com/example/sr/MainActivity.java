package com.example.sr;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private TableLayout tableLayout;
    private TableLayout existingRecordsTable;
    private int columnCount = 4;
    private ArrayList<String[]> medicalData = new ArrayList<>();
    private int editRowIndex = -1; // Track the row being edited
    private TextView infoText;
    private TextView noRecordsText;
    private String[] columnHints = {"Patient Name", "Age", "Diagnosis", "Prescription"}; // Keep for headers
    private String currentRecordId = null; // Track the current record ID for updates

    // Flag to track if we're in edit mode
    private boolean isEditMode = false;

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private MedicalRecordDatabase recordDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();
        recordDatabase = new MedicalRecordDatabase(this);
        recordDatabase.open();

        tableLayout = findViewById(R.id.tableLayout);
        existingRecordsTable = findViewById(R.id.existingRecordsTable);
        Button addRowButton = findViewById(R.id.addRowButton);
        Button submitButton = findViewById(R.id.submitButton);
        infoText = findViewById(R.id.infoText);
        noRecordsText = findViewById(R.id.noRecordsText);


        // Get data from ResultActivity
        Intent intent = getIntent();
        if (intent.hasExtra("medicalData")) {
            medicalData = (ArrayList<String[]>) intent.getSerializableExtra("medicalData");
            editRowIndex = intent.getIntExtra("editRowIndex", -1);

            if (editRowIndex != -1) {
                isEditMode = true;
            }

            // Get record ID if in edit mode
            if (intent.hasExtra("recordId")) {
                currentRecordId = intent.getStringExtra("recordId");
            }
        }

        // Initialize entry table
        initializeTable();

        // If in edit mode, populate with specific record data
        if (isEditMode) {
            populateEditData();
        } else {
            // If not in edit mode, just add an empty row to start with
            addRow();
        }

        // Load and display existing records
        loadExistingRecords();

        // Update info text visibility based on data
        updateInfoTextVisibility();

        addRowButton.setOnClickListener(view -> {
            addRow();
            view.startAnimation(AnimationUtils.loadAnimation(this, R.anim.row_animation));

            // Hide info text when row is added
            infoText.setVisibility(View.GONE);

            // Show a snackbar
            Snackbar.make(view, "New row added", Snackbar.LENGTH_SHORT).show();
        });

        submitButton.setOnClickListener(view -> {
            if (validateData()) {
                submitData();
            } else {
                Snackbar.make(view, "Please fill all required fields", Snackbar.LENGTH_LONG)
                        .setAction("OK", v -> {})
                        .show();
            }
        });

        // Update actionbar title based on edit mode
        if (isEditMode) {
            setTitle("Edit Patient Record");
        }
    }

    private void initializeTable() {
        TableRow headerRow = new TableRow(this);
        headerRow.setLayoutParams(new TableLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        for (String header : columnHints) {
            TextView textView = createHeaderTextView(header);
            headerRow.addView(textView);
        }

        tableLayout.addView(headerRow);
    }

    private void populateEditData() {
        // Only populate with the record being edited
        if (editRowIndex != -1 && editRowIndex < medicalData.size()) {
            String[] rowData = medicalData.get(editRowIndex);
            TableRow row = createDataRow(rowData);
            row.startAnimation(AnimationUtils.loadAnimation(this, R.anim.row_animation));
            tableLayout.addView(row);
        }
    }

    private TableRow createDataRow(String[] rowData) {
        TableRow row = new TableRow(this);
        row.setLayoutParams(new TableLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        for (int j = 0; j < columnCount; j++) {
            // Get the value to display (handle if rowData has more elements than we need)
            String value = j < rowData.length ? rowData[j] : "";

            // Create TextInputLayout with the style
            Context themedContext = new ContextThemeWrapper(this, R.style.AppInputField);
            TextInputLayout inputLayout = new TextInputLayout(themedContext);
            TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(
                    0,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    1.0f);
            layoutParams.setMargins(4, 8, 4, 8);
            inputLayout.setLayoutParams(layoutParams);
            inputLayout.setHint(""); // Remove hint here

            EditText editText = new EditText(this);
            editText.setText(value);
            editText.setPadding(16, 16, 16, 16);
            editText.setBackgroundResource(android.R.color.transparent);

            // Set appropriate input type for age field
            if (j == 1) { // Age column
                editText.setInputType(InputType.TYPE_CLASS_NUMBER);
            }

            // Add validation listener
            final int columnIndex = j;
            editText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    // Validate based on column
                    if (columnIndex == 1) { // Age column
                        try {
                            if (!s.toString().isEmpty() && Integer.parseInt(s.toString()) < 0) {
                                inputLayout.setError("Age cannot be negative");
                            } else {
                                inputLayout.setError(null);
                            }
                        } catch (NumberFormatException e) {
                            inputLayout.setError("Please enter a valid number");
                        }
                    } else if (s.toString().isEmpty()) {
                        inputLayout.setError("This field is required");
                    } else {
                        inputLayout.setError(null);
                    }
                }
            });

            inputLayout.addView(editText);
            row.addView(inputLayout);
        }

        return row;
    }

    private void addRow() {
        TableRow row = createDataRow(new String[]{"", "", "", ""});
        row.startAnimation(AnimationUtils.loadAnimation(this, R.anim.row_animation));
        tableLayout.addView(row);
    }

    private boolean validateData() {
        boolean isValid = true;

        for (int i = 1; i < tableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) tableLayout.getChildAt(i);

            for (int j = 0; j < columnCount; j++) {
                TextInputLayout inputLayout = (TextInputLayout) row.getChildAt(j);
                EditText editText = (EditText) inputLayout.getEditText();

                if (editText != null && editText.getText().toString().trim().isEmpty()) {
                    inputLayout.setError("This field is required");
                    isValid = false;
                }

                // Age validation
                if (j == 1 && editText != null) {
                    String ageText = editText.getText().toString().trim();
                    if (!ageText.isEmpty()) {
                        try {
                            int age = Integer.parseInt(ageText);
                            if (age < 0 || age > 150) {
                                inputLayout.setError("Please enter a valid age (0-150)");
                                isValid = false;
                            }
                        } catch (NumberFormatException e) {
                            inputLayout.setError("Please enter a valid number");
                            isValid = false;
                        }
                    }
                }
            }
        }

        return isValid;
    }

    private void submitData() {
        ArrayList<String[]> newMedicalData = new ArrayList<>();

        for (int i = 1; i < tableLayout.getChildCount(); i++) {
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            String[] rowData = new String[columnCount];

            for (int j = 0; j < columnCount; j++) {
                TextInputLayout inputLayout = (TextInputLayout) row.getChildAt(j);
                if (inputLayout != null && inputLayout.getEditText() != null) {
                    EditText editText = inputLayout.getEditText();
                    rowData[j] = editText.getText().toString().trim();
                } else {
                    rowData[j] = "";
                }
            }

            newMedicalData.add(rowData);
        }

        // Insert or update data in SQLite database
        db.beginTransaction();
        try {
            if (isEditMode) {
                // Update existing record
                updateRecord(newMedicalData.get(0));
                Toast.makeText(this, "Record updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                // Insert only new records
                insertRecords(newMedicalData);
                Toast.makeText(this, "Record saved successfully", Toast.LENGTH_SHORT).show();
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
        }

        // Refresh data from database and reload UI
        loadExistingRecords();

        // Reset input form
        if (!isEditMode) {
            resetInputForm();
        } else {
            // If we were in edit mode, go back to normal mode
            isEditMode = false;
            currentRecordId = null;
            editRowIndex = -1;
            setTitle("Medical Records");
            resetInputForm();
        }
    }

    private void resetInputForm() {
        // Clear all rows except header
        for (int i = tableLayout.getChildCount() - 1; i > 0; i--) {
            tableLayout.removeViewAt(i);
        }
        // Add a fresh empty row
        addRow();
    }

    private ArrayList<String[]> refreshDataFromDatabase() {
        ArrayList<String[]> refreshedData = new ArrayList<>();
        Cursor cursor = db.query(DatabaseHelper.TABLE_NAME, null, null, null, null, null, DatabaseHelper.COLUMN_ID + " DESC");

        while (cursor.moveToNext()) {
            String id = getColumnData(cursor, DatabaseHelper.COLUMN_ID);
            String name = getColumnData(cursor, DatabaseHelper.COLUMN_NAME);
            String age = getColumnData(cursor, DatabaseHelper.COLUMN_AGE);
            String diagnosis = getColumnData(cursor, DatabaseHelper.COLUMN_DIAGNOSIS);
            String prescription = getColumnData(cursor, DatabaseHelper.COLUMN_PRESCRIPTION);

            String[] rowData = new String[]{name, age, diagnosis, prescription, id};
            refreshedData.add(rowData);
        }
        cursor.close();

        return refreshedData;
    }

    private String getColumnData(Cursor cursor, String columnName) {
        int columnIndex = cursor.getColumnIndex(columnName);
        if (columnIndex >= 0) {
            return cursor.getString(columnIndex);
        }
        return "";
    }

    private void insertRecords(ArrayList<String[]> data) {
        for (String[] row : data) {
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_NAME, row[0]);
            values.put(DatabaseHelper.COLUMN_AGE, row[1]);
            values.put(DatabaseHelper.COLUMN_DIAGNOSIS, row[2]);
            values.put(DatabaseHelper.COLUMN_PRESCRIPTION, row[3]);

            db.insert(DatabaseHelper.TABLE_NAME, null, values);
        }
    }

    private void updateRecord(String[] rowData) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NAME, rowData[0]);
        values.put(DatabaseHelper.COLUMN_AGE, rowData[1]);
        values.put(DatabaseHelper.COLUMN_DIAGNOSIS, rowData[2]);
        values.put(DatabaseHelper.COLUMN_PRESCRIPTION, rowData[3]);

        // If we have the ID from the intent, use it directly
        if (currentRecordId != null) {
            String whereClause = DatabaseHelper.COLUMN_ID + "=?";
            String[] whereArgs = {currentRecordId};
            db.update(DatabaseHelper.TABLE_NAME, values, whereClause, whereArgs);
            return;
        }

        // Otherwise, use the data from the medicalData array
        if (editRowIndex != -1 && editRowIndex < medicalData.size() && medicalData.get(editRowIndex).length > 4) {
            String id = medicalData.get(editRowIndex)[4]; // Get ID from the last position
            String whereClause = DatabaseHelper.COLUMN_ID + "=?";
            String[] whereArgs = {id};
            db.update(DatabaseHelper.TABLE_NAME, values, whereClause, whereArgs);
        } else {
            // Fall back to updating based on matching all fields
            String whereClause = DatabaseHelper.COLUMN_NAME + "=? AND " +
                    DatabaseHelper.COLUMN_AGE + "=? AND " +
                    DatabaseHelper.COLUMN_DIAGNOSIS + "=? AND " +
                    DatabaseHelper.COLUMN_PRESCRIPTION + "=?";

            String[] originalData = medicalData.get(editRowIndex);
            String[] whereArgs = {originalData[0], originalData[1], originalData[2], originalData[3]};

            db.update(DatabaseHelper.TABLE_NAME, values, whereClause, whereArgs);
        }
    }

    private TextView createHeaderTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(16, 16, 16, 16);
        textView.setGravity(Gravity.CENTER);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));

        TableRow.LayoutParams params = new TableRow.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1.0f);
        params.setMargins(4, 0, 4, 8);
        textView.setLayoutParams(params);

        textView.setBackgroundResource(R.drawable.header_bg);
        return textView;
    }

    private void loadExistingRecords() {
        // Clear previous records
        existingRecordsTable.removeAllViews();

        // Add header row
        TableRow headerRow = new TableRow(this);
        for (String header : columnHints) {
            TextView textView = createHeaderTextView(header);
            headerRow.addView(textView);
        }

        // Add actions header
        TextView actionsHeader = createHeaderTextView("Actions");
        headerRow.addView(actionsHeader);

        existingRecordsTable.addView(headerRow);

        // Get data from database (ordered by newest first)
        medicalData = refreshDataFromDatabase();

        // Check if we have records
        if (medicalData.size() == 0) {
            noRecordsText.setVisibility(View.VISIBLE);
        } else {
            noRecordsText.setVisibility(View.GONE);

            // Display existing records
            for (int i = 0; i < medicalData.size(); i++) {
                String[] rowData = medicalData.get(i);

                TableRow row = new TableRow(this);
                row.setBackgroundResource(i % 2 == 0 ? R.drawable.cell_bg : R.drawable.alt_row_bg);

                // Add data columns
                for (int j = 0; j < columnCount; j++) {
                    TextView textView = new TextView(this);
                    textView.setText(rowData[j]);
                    textView.setPadding(16, 16, 16, 16);
                    textView.setGravity(Gravity.CENTER_VERTICAL);
                    textView.setTextColor(ContextCompat.getColor(this, R.color.colorDark));

                    TableRow.LayoutParams params = new TableRow.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            1.0f);
                    params.setMargins(4, 4, 4, 4);
                    textView.setLayoutParams(params);

                    row.addView(textView);
                }

                // Add action buttons
                TableRow.LayoutParams buttonParams = new TableRow.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                buttonParams.setMargins(4, 4, 4, 4);

                // Container for buttons
                TableRow buttonContainer = new TableRow(this);

                // Edit button
                MaterialButton editButton = new MaterialButton(this, null, R.style.EditButton);
                editButton.setText("Edit");
                editButton.setLayoutParams(buttonParams);

                final int index = i;
                editButton.setOnClickListener(v -> editRecord(index));

                // Delete button
                MaterialButton deleteButton = new MaterialButton(this, null, R.style.DeleteButton);
                deleteButton.setText("Delete");
                deleteButton.setLayoutParams(buttonParams);

                deleteButton.setOnClickListener(v -> deleteRecord(index));

                buttonContainer.addView(editButton);
                buttonContainer.addView(deleteButton);

                row.addView(buttonContainer);

                // Add to table with animation
                row.startAnimation(AnimationUtils.loadAnimation(this, R.anim.row_animation));
                existingRecordsTable.addView(row);
            }
        }
    }

    private void editRecord(int index) {
        if (index < 0 || index >= medicalData.size()) {
            return;
        }

        // Set edit mode flag
        isEditMode = true;
        editRowIndex = index;
        currentRecordId = medicalData.get(index)[4];

        // Update title
        setTitle("Edit Patient Record");

        // Clear current input form
        for (int i = tableLayout.getChildCount() - 1; i > 0; i--) {
            tableLayout.removeViewAt(i);
        }

        // Add the row being edited to the input form
        TableRow row = createDataRow(medicalData.get(index));
        row.startAnimation(AnimationUtils.loadAnimation(this, R.anim.row_animation));
        tableLayout.addView(row);
    }

    private void deleteRecord(int index) {
        if (index < 0 || index >= medicalData.size()) {
            return;
        }

        // Get record ID
        String id = medicalData.get(index)[4];

        // Delete from database
        String whereClause = DatabaseHelper.COLUMN_ID + "=?";
        String[] whereArgs = {id};

        int rowsDeleted = db.delete(DatabaseHelper.TABLE_NAME, whereClause, whereArgs);
        if (rowsDeleted > 0) {
            // Remove from our array
            medicalData.remove(index);

            // Reload the UI
            loadExistingRecords();

            Toast.makeText(this, "Record deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to delete record", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateInfoTextVisibility() {
        if (tableLayout.getChildCount() <= 1) { // Only header row
            infoText.setVisibility(View.VISIBLE);
        } else {
            infoText.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null) {
            db.close();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
        if (recordDatabase != null) {
            recordDatabase.close();
        }
    }

    @Override
    public void onBackPressed() {
        if (isEditMode) {
            // If in edit mode, cancel edit and reload records
            isEditMode = false;
            editRowIndex = -1;
            currentRecordId = null;
            setTitle("Medical Records");

            // Reset input form
            resetInputForm();

            // Reload existing records
            loadExistingRecords();
        } else {
            super.onBackPressed();
        }
    }
}