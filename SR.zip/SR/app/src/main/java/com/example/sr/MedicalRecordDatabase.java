package com.example.sr;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class MedicalRecordDatabase {

    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;

    public MedicalRecordDatabase(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        if (db != null && db.isOpen()) {
            db.close();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
    }

    // Add a new medical record
    public long addRecord(String patientName, String age, String diagnosis, String prescription) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NAME, patientName);
        values.put(DatabaseHelper.COLUMN_AGE, age);
        values.put(DatabaseHelper.COLUMN_DIAGNOSIS, diagnosis);
        values.put(DatabaseHelper.COLUMN_PRESCRIPTION, prescription);
        return db.insert(DatabaseHelper.TABLE_NAME, null, values);
    }

    // Update an existing record by ID
    public boolean updateRecord(String id, String patientName, String age, String diagnosis, String prescription) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NAME, patientName);
        values.put(DatabaseHelper.COLUMN_AGE, age);
        values.put(DatabaseHelper.COLUMN_DIAGNOSIS, diagnosis);
        values.put(DatabaseHelper.COLUMN_PRESCRIPTION, prescription);

        String whereClause = DatabaseHelper.COLUMN_ID + "=?";
        String[] whereArgs = {id};

        int rowsAffected = db.update(DatabaseHelper.TABLE_NAME, values, whereClause, whereArgs);
        return rowsAffected > 0;
    }

    // Delete a record by ID
    public boolean deleteRecord(String id) {
        String whereClause = DatabaseHelper.COLUMN_ID + "=?";
        String[] whereArgs = {id};
        int rowsDeleted = db.delete(DatabaseHelper.TABLE_NAME, whereClause, whereArgs);
        return rowsDeleted > 0;
    }

    // Get all medical records including ID
    public ArrayList<String[]> getAllRecords() {
        ArrayList<String[]> records = new ArrayList<>();
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                DatabaseHelper.COLUMN_NAME + " ASC" // Order by patient name
        );

        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ID);
            int nameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
            int ageIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_AGE);
            int diagnosisIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_DIAGNOSIS);
            int prescriptionIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_PRESCRIPTION);

            do {
                String[] record = new String[5]; // Including ID as the last element
                record[0] = cursor.getString(nameIndex);
                record[1] = cursor.getString(ageIndex);
                record[2] = cursor.getString(diagnosisIndex);
                record[3] = cursor.getString(prescriptionIndex);
                record[4] = cursor.getString(idIndex); // Store ID as the last element
                records.add(record);
            } while (cursor.moveToNext());

            cursor.close();
        }
        return records;
    }

    // Search records by query string (searches across all fields)
    public ArrayList<String[]> searchRecords(String query) {
        ArrayList<String[]> records = new ArrayList<>();
        String searchQuery = "%" + query + "%";
        String whereClause =
                DatabaseHelper.COLUMN_NAME + " LIKE ? OR " +
                        DatabaseHelper.COLUMN_AGE + " LIKE ? OR " +
                        DatabaseHelper.COLUMN_DIAGNOSIS + " LIKE ? OR " +
                        DatabaseHelper.COLUMN_PRESCRIPTION + " LIKE ?";
        String[] whereArgs = {searchQuery, searchQuery, searchQuery, searchQuery};

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ID);
            int nameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
            int ageIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_AGE);
            int diagnosisIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_DIAGNOSIS);
            int prescriptionIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_PRESCRIPTION);

            do {
                String[] record = new String[5];
                record[0] = cursor.getString(nameIndex);
                record[1] = cursor.getString(ageIndex);
                record[2] = cursor.getString(diagnosisIndex);
                record[3] = cursor.getString(prescriptionIndex);
                record[4] = cursor.getString(idIndex);
                records.add(record);
            } while (cursor.moveToNext());

            cursor.close();
        }
        return records;
    }

    // Get a single record by ID
    public String[] getRecordById(String id) {
        String whereClause = DatabaseHelper.COLUMN_ID + "=?";
        String[] whereArgs = {id};

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                null
        );

        String[] record = new String[5];
        if (cursor != null && cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ID);
            int nameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
            int ageIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_AGE);
            int diagnosisIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_DIAGNOSIS);
            int prescriptionIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_PRESCRIPTION);

            record[0] = cursor.getString(nameIndex);
            record[1] = cursor.getString(ageIndex);
            record[2] = cursor.getString(diagnosisIndex);
            record[3] = cursor.getString(prescriptionIndex);
            record[4] = cursor.getString(idIndex);

            cursor.close();
            return record;
        }
        return null;
    }

    // Get record count
    public int getRecordCount() {
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + DatabaseHelper.TABLE_NAME, null);
        int count = 0;
        if (cursor != null) {
            cursor.moveToFirst();
            count = cursor.getInt(0);
            cursor.close();
        }
        return count;
    }

    // Clear all records
    public void clearAllRecords() {
        db.execSQL("DELETE FROM " + DatabaseHelper.TABLE_NAME);
    }
}