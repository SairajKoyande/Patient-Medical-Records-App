    package com.example.sr;

    import android.content.DialogInterface;
    import android.content.Intent;
    import android.database.sqlite.SQLiteDatabase;
    import android.graphics.Typeface;
    import android.os.Bundle;
    import android.text.Editable;
    import android.text.TextWatcher;
    import android.view.Gravity;
    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.view.animation.AnimationUtils;
    import android.widget.Button;
    import android.widget.EditText;
    import android.widget.TableLayout;
    import android.widget.TableRow;
    import android.widget.TextView;
    import android.widget.Toast;

    import androidx.appcompat.app.AlertDialog;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.appcompat.widget.Toolbar;
    import androidx.core.content.ContextCompat;

    import com.google.android.material.button.MaterialButton;
    import com.google.android.material.floatingactionbutton.FloatingActionButton;
    import com.google.android.material.snackbar.Snackbar;
    import com.google.android.material.textfield.TextInputEditText;

    import java.util.ArrayList;
    import java.util.Locale;

    public class ResultActivity extends AppCompatActivity {
        private TableLayout resultTable;
        private ArrayList<String[]> medicalData;
        private ArrayList<String[]> filteredData;
        private TextView emptyStateText;
        private TextView recordCountText;
        private TextInputEditText searchInput;
        private DatabaseHelper dbHelper;
        private SQLiteDatabase db;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_result);

            // Setup database
            dbHelper = new DatabaseHelper(this);
            db = dbHelper.getWritableDatabase();

            // Setup toolbar
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            resultTable = findViewById(R.id.resultTable);
            Button backButton = findViewById(R.id.backButton);
            emptyStateText = findViewById(R.id.emptyStateText);
            recordCountText = findViewById(R.id.recordCountText);
            searchInput = findViewById(R.id.searchInput);
            FloatingActionButton exportFab = findViewById(R.id.exportFab);

            // Get data from MainActivity
            medicalData = (ArrayList<String[]>) getIntent().getSerializableExtra("medicalData");
            if (medicalData == null) {
                medicalData = new ArrayList<>();
            }
            filteredData = new ArrayList<>(medicalData);

            // Set record count
            updateRecordCount();

            // Display data in table
            displayData();

            // Setup search functionality
            setupSearch();

            backButton.setOnClickListener(view -> {
                Intent intent = new Intent(ResultActivity.this, MainActivity.class);
                intent.putExtra("medicalData", medicalData);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                finish();
            });

            exportFab.setOnClickListener(view -> {
                // Show export options dialog
                showExportOptionsDialog();
            });
        }

        private void setupSearch() {
            searchInput.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    filterData(s.toString().toLowerCase().trim());
                }
            });
        }

        private void filterData(String query) {
            filteredData.clear();

            if (query.isEmpty()) {
                filteredData.addAll(medicalData);
            } else {
                for (String[] rowData : medicalData) {
                    boolean matchFound = false;
                    // Only search through visible data columns (not the hidden ID)
                    for (int i = 0; i < 4; i++) {
                        if (rowData[i] != null && rowData[i].toLowerCase().contains(query)) {
                            matchFound = true;
                            break;
                        }
                    }
                    if (matchFound) {
                        filteredData.add(rowData);
                    }
                }
            }

            displayData();
            updateRecordCount();
        }

        private void updateRecordCount() {
            recordCountText.setText(String.format(Locale.getDefault(), "%d Records", filteredData.size()));
        }

        private void displayData() {
            resultTable.removeAllViews();

            // Table Headers
            TableRow headerRow = new TableRow(this);
            String[] headers = {"Patient Name", "Age", "Diagnosis", "Prescription", "Actions"};
            for (String header : headers) {
                headerRow.addView(createTextView(header, true));
            }
            resultTable.addView(headerRow);

            // Check if data is empty
            if (filteredData.isEmpty()) {
                emptyStateText.setVisibility(View.VISIBLE);
                return;
            } else {
                emptyStateText.setVisibility(View.GONE);
            }

            // Display Data Rows
            for (int i = 0; i < filteredData.size(); i++) {
                TableRow row = new TableRow(this);
                row.setBackgroundResource(i % 2 == 0 ? R.drawable.cell_bg : R.drawable.alt_row_bg);

                // Add row with animation
                row.startAnimation(AnimationUtils.loadAnimation(this, R.anim.row_animation));

                // Add data cells - only first 4 columns, ID is in position 4
                for (int j = 0; j < 4 && j < filteredData.get(i).length; j++) {
                    row.addView(createTextView(filteredData.get(i)[j], false));
                }

                // Create buttons container
                TableRow.LayoutParams buttonParams = new TableRow.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                buttonParams.setMargins(4, 4, 4, 4);

                // Add Edit Button
                MaterialButton editButton = new MaterialButton(this, null, R.style.EditButton);
                editButton.setText("Edit");
                editButton.setLayoutParams(buttonParams);

                int finalI = getOriginalIndex(filteredData.get(i));
                editButton.setOnClickListener(view -> editRow(finalI));

                // Add Delete Button
                MaterialButton deleteButton = new MaterialButton(this, null, R.style.DeleteButton);
                deleteButton.setText("Delete");
                deleteButton.setLayoutParams(buttonParams);
                deleteButton.setOnClickListener(view -> confirmDelete(finalI));

                // Add buttons to row
                TableRow.LayoutParams actionCellParams = new TableRow.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);

                // Create a container for buttons
                TableRow buttonRow = new TableRow(this);
                buttonRow.addView(editButton);
                buttonRow.addView(deleteButton);

                // Add button row to main row
                row.addView(buttonRow, actionCellParams);
                resultTable.addView(row);
            }
        }

        private int getOriginalIndex(String[] rowData) {
            for (int i = 0; i < medicalData.size(); i++) {
                if (rowData == medicalData.get(i)) {
                    return i;
                }
            }
            return -1;
        }

        private void confirmDelete(int rowIndex) {
            if (rowIndex < 0 || rowIndex >= medicalData.size()) {
                Toast.makeText(this, "Invalid record index", Toast.LENGTH_SHORT).show();
                return;
            }

            View dialogView = LayoutInflater.from(this).inflate(R.layout.delete_confirmation_dialog, null);
            TextView messageText = dialogView.findViewById(R.id.deleteConfirmMessage);

            String patientName = medicalData.get(rowIndex)[0];
            messageText.setText("Are you sure you want to delete the record for " + patientName + "?");

            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setView(dialogView)
                    .create();

            Button cancelButton = dialogView.findViewById(R.id.cancelDeleteButton);
            Button confirmButton = dialogView.findViewById(R.id.confirmDeleteButton);

            cancelButton.setOnClickListener(v -> dialog.dismiss());

            confirmButton.setOnClickListener(v -> {
                if (deleteRow(rowIndex)) {
                    dialog.dismiss();
                    Snackbar.make(resultTable, "Record deleted", Snackbar.LENGTH_SHORT).show();
                } else {
                    dialog.dismiss();
                    Toast.makeText(ResultActivity.this, "Failed to delete record", Toast.LENGTH_SHORT).show();
                }
            });

            dialog.show();
        }

        private void editRow(int rowIndex) {
            if (rowIndex < 0 || rowIndex >= medicalData.size()) {
                Toast.makeText(this, "Invalid record index", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("editRowIndex", rowIndex);
            intent.putExtra("medicalData", medicalData);

            // If we have record ID stored, pass it as well
            if (medicalData.get(rowIndex).length > 4) {
                intent.putExtra("recordId", medicalData.get(rowIndex)[4]);
            }

            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            finish();
        }

        private boolean deleteRow(int rowIndex) {
            if (rowIndex < 0 || rowIndex >= medicalData.size()) {
                return false;
            }

            String[] rowToDelete = medicalData.get(rowIndex);
            boolean deleted = false;

            // Check if we have the ID in the row data (should be at index 4)
            if (rowToDelete.length > 4 && rowToDelete[4] != null && !rowToDelete[4].isEmpty()) {
                // Delete using ID
                String whereClause = DatabaseHelper.COLUMN_ID + "=?";
                String[] whereArgs = {rowToDelete[4]};

                deleted = db.delete(DatabaseHelper.TABLE_NAME, whereClause, whereArgs) > 0;
            } else {
                // Fallback: Delete by matching all fields
                String whereClause = DatabaseHelper.COLUMN_NAME + "=? AND " +
                        DatabaseHelper.COLUMN_AGE + "=? AND " +
                        DatabaseHelper.COLUMN_DIAGNOSIS + "=? AND " +
                        DatabaseHelper.COLUMN_PRESCRIPTION + "=?";

                String[] whereArgs = {
                        rowToDelete[0], rowToDelete[1], rowToDelete[2], rowToDelete[3]
                };

                deleted = db.delete(DatabaseHelper.TABLE_NAME, whereClause, whereArgs) > 0;
            }

            if (deleted) {
                // Remove from in-memory arrays
                medicalData.remove(rowIndex);
                filteredData.clear();
                filteredData.addAll(medicalData);

                // Apply current filter
                if (searchInput.getText() != null && !searchInput.getText().toString().isEmpty()) {
                    filterData(searchInput.getText().toString().toLowerCase().trim());
                }

                displayData();
                updateRecordCount();
                return true;
            }

            return false;
        }

        private TextView createTextView(String text, boolean isHeader) {
            TextView textView = new TextView(this);
            textView.setText(text != null ? text : "");
            textView.setPadding(16, 16, 16, 16);
            textView.setGravity(Gravity.CENTER);

            if (isHeader) {
                textView.setTypeface(null, Typeface.BOLD);
                textView.setTextColor(ContextCompat.getColor(this, R.color.colorPrimary));
                textView.setBackgroundResource(R.drawable.header_bg);
            } else {
                textView.setTextColor(ContextCompat.getColor(this, R.color.colorDark));
            }

            textView.setLayoutParams(new TableRow.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            return textView;
        }

        private void showExportOptionsDialog() {
            final String[] options = {"Export as CSV", "Export as PDF", "Share data"};

            new AlertDialog.Builder(this)
                    .setTitle("Export Options")
                    .setItems(options, (dialog, which) -> {
                        switch (which) {
                            case 0:
                                // Export as CSV option selected
                                Toast.makeText(ResultActivity.this,
                                        "CSV export feature would be implemented here",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            case 1:
                                // Export as PDF option selected
                                Toast.makeText(ResultActivity.this,
                                        "PDF export feature would be implemented here",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            case 2:
                                // Share data option selected
                                shareData();
                                break;
                        }
                    })
                    .show();
        }

        private void shareData() {
            StringBuilder data = new StringBuilder();
            data.append("Medical Records\n\n");

            for (String[] record : filteredData) {
                data.append("Patient: ").append(record[0]).append("\n");
                data.append("Age: ").append(record[1]).append("\n");
                data.append("Diagnosis: ").append(record[2]).append("\n");
                data.append("Prescription: ").append(record[3]).append("\n\n");
            }

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Medical Records");
            shareIntent.putExtra(Intent.EXTRA_TEXT, data.toString());
            startActivity(Intent.createChooser(shareIntent, "Share Medical Records"));
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            if (db != null) {
                db.close();
            }
            if (dbHelper != null) {
                dbHelper.close();
            }
        }
    }