package com.example.sr;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "medical_records7.db";
    private static final int DATABASE_VERSION = 4; // Increased version number for schema change

    public static final String TABLE_NAME = "patient_records";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "patient_name";
    public static final String COLUMN_AGE = "age";
    public static final String COLUMN_DIAGNOSIS = "diagnosis";
    public static final String COLUMN_PRESCRIPTION = "prescription";
    public static final String COLUMN_POSITION = "position"; // Added position column

    private static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_NAME + " TEXT NOT NULL, " +
                    COLUMN_AGE + " TEXT NOT NULL, " +
                    COLUMN_DIAGNOSIS + " TEXT NOT NULL, " +
                    COLUMN_PRESCRIPTION + " TEXT NOT NULL, " +
                    COLUMN_POSITION + " INTEGER DEFAULT 0);"; // Added position column with default value

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 4) {
            // Add the position column if upgrading from a version before it existed
            try {
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " +
                        COLUMN_POSITION + " INTEGER DEFAULT 0");
            } catch (Exception e) {
                // If altering fails (table doesn't exist or column already exists)
                // Drop and recreate the table
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
                onCreate(db);
            }
        } else {
            // For other version changes, recreate the table
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }
    }

    // Method to clear all records from the table
    public void clearAllRecords(SQLiteDatabase db) {
        db.execSQL("DELETE FROM " + TABLE_NAME);
    }
}